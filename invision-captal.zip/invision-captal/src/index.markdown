<header>
    <h1>Forex Trading App</h1>
    <nav>
        <ul>
            <li><a href="#journal">Trading Journal</a></li>
            <li><a href="#signals">Trading Signals</a></li>
            <li><a href="#education">Education</a></li>
        </ul>
    </nav>
</header>

<section id="journal">
    <h2>Trading Journal</h2>
    <p>Track and analyze your trades to improve your strategy.</p>
    <textarea placeholder="Enter your trade details here..."></textarea>
</section>

<section id="signals">
    <h2>Trading Signals</h2>
    <p>Receive alerts and notifications on market trends.</p>
    <button onclick="alert('Notifications Enabled!')">Enable Notifications</button>
</section>

<section id="education">
    <h2>Education</h2>
    <p>Learn about Forex trading strategies and risk management.</p>
    <article>
        <h3>Understanding Pips and Leverage</h3>
        <p>Forex trading involves terms like pips, leverage, and margin...</p>
    </article>
</section>

<footer>
    <p>&copy; 2025 Forex Trading App</p>
</footer>

