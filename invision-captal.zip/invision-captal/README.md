# Invision captal

A Pen created on CodePen.

Original URL: [https://codepen.io/Sydwell-Msutu/pen/azbbxZE](https://codepen.io/Sydwell-Msutu/pen/azbbxZE).

we are creating an app for beginner traders who are still in the trenches .